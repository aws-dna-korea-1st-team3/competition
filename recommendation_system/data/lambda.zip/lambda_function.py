import json
from random import randrange
import random
import string
 
def lambda_handler(event, context):
    print("Received event: " + json.dumps(event))
    print("Received context: " +  str(context))
    segment_endpoints = event["Endpoints"]
    new_segment = dict()
    for endpoint_id in segment_endpoints.keys():
        endpoint = segment_endpoints[endpoint_id]
        if supported_endpoint(endpoint):
            new_segment[endpoint_id] = add_recommendation(endpoint)
 
    print("Returning endpoints: " + json.dumps(new_segment))
    return new_segment
 
def supported_endpoint(endpoint):
    return True
 
def add_recommendation(endpoint):
    endpoint["Recommendations"] = dict()
 
    customTitleList = list()
    for i,item in enumerate(endpoint["RecommendationItems"]):
        item = int(item)
        if item = 1:
            customTitleList.insert(i, "그림을 그리는 일")
        elif item = 2:
            customTitleList.insert(i, "유진의 환상특급열차 vol.1")
        elif item = 3:
            customTitleList.insert(i, "회사원 채대리")
        elif item = 4:
            customTitleList.insert(i, "뿌리네 이야기")
        elif item = 5:
            customTitleList.insert(i, "논스톱 서브웨이")
        elif item = 6:
            customTitleList.insert(i, "보다")
        elif item = 7:
            customTitleList.insert(i, "조선롹스타")
        elif item = 8:
            customTitleList.insert(i, "낭만도시")
        elif item = 9:
            customTitleList.insert(i, "꿈의 반려")
        elif item = 10:
            customTitleList.insert(i, "꼬꼬댁 대소동")
        elif item = 11:
            customTitleList.insert(i, "별이 내린 여름날")
        elif item = 12:
            customTitleList.insert(i, "사랑을 너에게")
        elif item = 13:
            customTitleList.insert(i, "종이비행기를 날리면")
        elif item = 14:
            customTitleList.insert(i, "그때, 우리가 있었던 계절")
        elif item = 15:
            customTitleList.insert(i, "환상여행")
        elif item = 16:
            customTitleList.insert(i, "화초 죽이기")
        elif item = 17:
            customTitleList.insert(i, "섬의 봄")
        elif item = 18:
            customTitleList.insert(i, "고냥 일기")
        elif item = 19:
            customTitleList.insert(i, "나는 슬기")
        elif item = 20:
            customTitleList.insert(i, "요괴 뚝딱 한끼 뚝딱")
        elif item = 21:
            customTitleList.insert(i, "My Killer")
        elif item = 22:
            customTitleList.insert(i, "안녕안녕해")
        elif item = 23:
            customTitleList.insert(i, "은퇴 요리사")
        elif item = 24:
            customTitleList.insert(i, "별일 없이 산다")
        elif item = 25:
            customTitleList.insert(i, "이웃집 남녀 in 교토")
        elif item = 26:
            customTitleList.insert(i, "오버사이즈 러브")
        elif item = 27:
            customTitleList.insert(i, "개구리공주")
        elif item = 28:
            customTitleList.insert(i, "안녕 이바, 안녕 나의 고양이")
        elif item = 29:
            customTitleList.insert(i, "직장인 감자")
        elif item = 30:
            customTitleList.insert(i, "나사들의 이야기")
        elif item = 31:
            customTitleList.insert(i, "만화경 편집부는 9층입니다")
        elif item = 32:
            customTitleList.insert(i, "Return")
        elif item = 33:
            customTitleList.insert(i, "가가바이러스")
        elif item = 34:
            customTitleList.insert(i, "오픈했어요 매직컬 마카롱")
        elif item = 35:
            customTitleList.insert(i, "페어리링")
        elif item = 36:
            customTitleList.insert(i, "좋은 남편")
        elif item = 37:
            customTitleList.insert(i, "매화꽃이 피었나이다")
        elif item = 38:
            customTitleList.insert(i, "오목왕")
        elif item = 39:
            customTitleList.insert(i, "너의 행성 B126으로")
        elif item = 40:
            customTitleList.insert(i, "나의 연애 D-day")
        elif item = 41:
            customTitleList.insert(i, "동네 한 바퀴")
        elif item = 42:
            customTitleList.insert(i, "그리고 또")
        elif item = 43:
            customTitleList.insert(i, "곁에")
        elif item = 44:
            customTitleList.insert(i, "다름이 아니라")
        elif item = 45:
            customTitleList.insert(i, "결혼교과시간")
        elif item = 46:
            customTitleList.insert(i, "윌슨가의 비밀")
        elif item = 47:
            customTitleList.insert(i, "가슴으로 들어요")
        elif item = 48:
            customTitleList.insert(i, "Winter Game")
        elif item = 49:
            customTitleList.insert(i, "오늘을 살아본 게 아니잖아")
        elif item = 50:
            customTitleList.insert(i, "눈맞춤")
        elif item = 51:
            customTitleList.insert(i, "매일 한 칸씩")
        elif item = 52:
            customTitleList.insert(i, "홈리스 탐정")
        elif item = 53:
            customTitleList.insert(i, "어느 날, 문득")
        elif item = 54:
            customTitleList.insert(i, "하루의 끝을 당신과")
        
    endpoint["Recommendations"]["Title"] = customTitleList
    
    return endpoint