import json
from random import randrange
import random
import string
 
def lambda_handler(event, context):
    print("Received event: " + json.dumps(event))
    print("Received context: " +  str(context))
    segment_endpoints = event["Endpoints"]
    new_segment = dict()
    for endpoint_id in segment_endpoints.keys():
        endpoint = segment_endpoints[endpoint_id]
        if supported_endpoint(endpoint):
            new_segment[endpoint_id] = add_recommendation(endpoint)
 
    print("Returning endpoints: " + json.dumps(new_segment))
    return new_segment
 
def supported_endpoint(endpoint):
    return True
 
def add_recommendation(endpoint):
    endpoint["Recommendations"] = dict()
 
    customTitleList = list()
    customGenreList = list()
    for i,item in enumerate(endpoint["RecommendationItems"]):
        item = int(item)
        if item = 38:
            customTitleList.insert(i, "오목왕")
            customGenreList.insert(i, "소년물|미스터리")
        elif item = 2:
            customTitleList.insert(i, "유진의 환상특급열차 vol.1")
            customGenreList.insert(i, "에피소드|판타지|옴니버스")
        elif item = 35:
            customTitleList.insert(i, "페어리링")
            customGenreList.insert(i, "에피소드|판타지|옴니버스")
        elif item = 23:
            customTitleList.insert(i, "은퇴 요리사")
            customGenreList.insert(i, "소년물|에피소드|판타지")
        elif item = 9:
            customTitleList.insert(i, "꿈의 반려")
            customGenreList.insert(i, "소년물|에피소드|유머")
        elif item = 29:
            customTitleList.insert(i, "직장인 감자")
            customGenreList.insert(i, "에피소드|학원")
        
    endpoint["Recommendations"]["Title"] = customTitleList
    endpoint["Recommendations"]["Genre"] = customGenreList
    
    return endpoint